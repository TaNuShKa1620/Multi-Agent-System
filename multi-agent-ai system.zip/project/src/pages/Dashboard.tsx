import React, { useState } from 'react';
import { FileText, Upload, CheckCircle, AlertCircle } from 'lucide-react';
import FileUpload from '../components/FileUpload';
import TextInput from '../components/TextInput';
import ProcessingFlow from '../components/ProcessingFlow';
import ResultDisplay from '../components/ResultDisplay';
import { useMemory } from '../context/MemoryContext';
import { useToast } from '../context/ToastContext';
import { classifyInput, processInput } from '../services/agentService';

const Dashboard: React.FC = () => {
  const [inputType, setInputType] = useState<'file' | 'text'>('file');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStage, setCurrentStage] = useState(0);
  const [result, setResult] = useState<any>(null);
  const { addToMemory } = useMemory();
  const { showToast } = useToast();

  const handleSubmit = async (data: string | File) => {
    try {
      setIsProcessing(true);
      setCurrentStage(1);
      
      // Classify the input
      const classification = await classifyInput(data);
      setCurrentStage(2);
      
      // Process with appropriate agent
      const processedResult = await processInput(data, classification);
      setCurrentStage(3);
      
      // Store in memory
      const memoryEntry = {
        id: processedResult.id,
        timestamp: new Date().toISOString(),
        classification: classification,
        result: processedResult
      };
      
      addToMemory(memoryEntry);
      setResult(processedResult);
      
      showToast({
        type: 'success',
        message: `Successfully processed ${classification.format} as ${classification.intent}`,
      });
    } catch (error) {
      console.error('Processing error:', error);
      showToast({
        type: 'error',
        message: `Error processing input: ${error instanceof Error ? error.message : 'Unknown error'}`,
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setCurrentStage(0);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Multi-Agent AI System</h1>
        <p className="text-gray-600">
          Upload or paste content to be classified and processed by specialized AI agents
        </p>
      </div>

      {!result ? (
        <>
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex space-x-4 mb-6">
              <button
                className={`flex-1 py-3 px-4 rounded-md flex items-center justify-center space-x-2 ${
                  inputType === 'file'
                    ? 'bg-blue-100 text-blue-700 border border-blue-300'
                    : 'bg-gray-100 text-gray-700 border border-gray-300 hover:bg-gray-200'
                }`}
                onClick={() => setInputType('file')}
              >
                <Upload size={20} />
                <span>Upload File</span>
              </button>
              <button
                className={`flex-1 py-3 px-4 rounded-md flex items-center justify-center space-x-2 ${
                  inputType === 'text'
                    ? 'bg-blue-100 text-blue-700 border border-blue-300'
                    : 'bg-gray-100 text-gray-700 border border-gray-300 hover:bg-gray-200'
                }`}
                onClick={() => setInputType('text')}
              >
                <FileText size={20} />
                <span>Paste Text</span>
              </button>
            </div>

            {inputType === 'file' ? (
              <FileUpload onSubmit={handleSubmit} isProcessing={isProcessing} />
            ) : (
              <TextInput onSubmit={handleSubmit} isProcessing={isProcessing} />
            )}
          </div>

          {isProcessing && (
            <div className="bg-white rounded-lg shadow-md p-6 mb-8">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Processing Flow</h2>
              <ProcessingFlow currentStage={currentStage} />
            </div>
          )}
        </>
      ) : (
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Processing Results</h2>
            <button
              onClick={handleReset}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-md flex items-center space-x-2 transition-colors"
            >
              <span>Process New Input</span>
            </button>
          </div>
          <ResultDisplay result={result} />
        </div>
      )}

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            <CheckCircle className="h-6 w-6 text-blue-600" />
          </div>
          <div className="ml-3">
            <h3 className="text-lg font-medium text-blue-800">Supported Input Types</h3>
            <div className="mt-2 text-sm text-blue-700">
              <ul className="list-disc pl-5 space-y-1">
                <li>JSON data (structured information)</li>
                <li>Email content (plain text)</li>
                <li>PDF documents (coming soon)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;