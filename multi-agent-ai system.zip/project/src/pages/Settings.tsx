import React, { useState } from 'react';
import { Settings as SettingsIcon, Save, RefreshCw } from 'lucide-react';
import { useToast } from '../context/ToastContext';

const Settings: React.FC = () => {
  const { showToast } = useToast();
  const [settings, setSettings] = useState({
    memoryRetentionDays: 30,
    enablePdfProcessing: false,
    defaultAgent: 'auto',
    loggingLevel: 'info',
  });

  const [isSaving, setIsSaving] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setSettings({
      ...settings,
      [name]: type === 'checkbox' 
        ? (e.target as HTMLInputElement).checked 
        : type === 'number' 
          ? parseInt(value) 
          : value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    // Simulate saving
    setTimeout(() => {
      setIsSaving(false);
      showToast({
        type: 'success',
        message: 'Settings saved successfully',
      });
    }, 1000);
  };

  const handleReset = () => {
    setSettings({
      memoryRetentionDays: 30,
      enablePdfProcessing: false,
      defaultAgent: 'auto',
      loggingLevel: 'info',
    });
    
    showToast({
      type: 'info',
      message: 'Settings reset to defaults',
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center space-x-2 mb-6">
        <SettingsIcon className="h-6 w-6 text-blue-600" />
        <h1 className="text-2xl font-bold text-gray-800">Settings</h1>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-4">System Configuration</h2>
            
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div>
                <label htmlFor="memoryRetentionDays" className="block text-sm font-medium text-gray-700 mb-1">
                  Memory Retention (days)
                </label>
                <input
                  type="number"
                  id="memoryRetentionDays"
                  name="memoryRetentionDays"
                  value={settings.memoryRetentionDays}
                  onChange={handleChange}
                  min="1"
                  max="365"
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm border p-2"
                />
              </div>

              <div>
                <label htmlFor="loggingLevel" className="block text-sm font-medium text-gray-700 mb-1">
                  Logging Level
                </label>
                <select
                  id="loggingLevel"
                  name="loggingLevel"
                  value={settings.loggingLevel}
                  onChange={handleChange}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm border p-2"
                >
                  <option value="error">Error</option>
                  <option value="warn">Warning</option>
                  <option value="info">Info</option>
                  <option value="debug">Debug</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="defaultAgent" className="block text-sm font-medium text-gray-700 mb-1">
                  Default Agent
                </label>
                <select
                  id="defaultAgent"
                  name="defaultAgent"
                  value={settings.defaultAgent}
                  onChange={handleChange}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm border p-2"
                >
                  <option value="auto">Auto (Classifier)</option>
                  <option value="json">JSON Agent</option>
                  <option value="email">Email Agent</option>
                  <option value="pdf">PDF Agent</option>
                </select>
              </div>

              <div className="flex items-center h-full pt-6">
                <input
                  type="checkbox"
                  id="enablePdfProcessing"
                  name="enablePdfProcessing"
                  checked={settings.enablePdfProcessing}
                  onChange={handleChange}
                  className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="enablePdfProcessing" className="ml-2 block text-sm text-gray-700">
                  Enable PDF Processing (Beta)
                </label>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-gray-200 flex justify-end space-x-3">
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Reset to Defaults
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
                isSaving ? 'bg-blue-400' : 'bg-blue-600 hover:bg-blue-700'
              } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
            >
              {isSaving ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                    <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Settings
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Agent Information</h2>
        
        <div className="space-y-4">
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-md font-medium text-blue-600 mb-2">Classifier Agent</h3>
            <p className="text-sm text-gray-600">
              Determines the input format and intent, then routes to the appropriate specialized agent.
            </p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-md font-medium text-yellow-600 mb-2">JSON Agent</h3>
            <p className="text-sm text-gray-600">
              Processes structured JSON payloads, validates schemas, and flags anomalies or missing fields.
            </p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-md font-medium text-green-600 mb-2">Email Agent</h3>
            <p className="text-sm text-gray-600">
              Extracts sender, intent, and urgency from email content, formats for CRM-style usage.
            </p>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="text-md font-medium text-red-600 mb-2">PDF Agent (Coming Soon)</h3>
            <p className="text-sm text-gray-600">
              Will extract text and structured data from PDF documents when enabled.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;