import React, { useState } from 'react';
import { ChevronDown, ChevronUp, FileText, Mail, FileJson } from 'lucide-react';

interface ResultDisplayProps {
  result: any;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  const [showRaw, setShowRaw] = useState(false);

  if (!result) return null;

  const getFormatIcon = () => {
    switch (result.classification?.format) {
      case 'JSON':
        return <FileJson className="h-6 w-6 text-yellow-500" />;
      case 'Email':
        return <Mail className="h-6 w-6 text-blue-500" />;
      case 'PDF':
        return <FileText className="h-6 w-6 text-red-500" />;
      default:
        return <FileText className="h-6 w-6 text-gray-500" />;
    }
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3 pb-4 border-b border-gray-200">
        {getFormatIcon()}
        <div>
          <h3 className="text-lg font-medium text-gray-900">
            {result.classification?.format} - {result.classification?.intent}
          </h3>
          <p className="text-sm text-gray-500">
            Processed {formatTimestamp(result.timestamp)}
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {result.extractedData && (
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Extracted Data</h4>
            <div className="space-y-2">
              {Object.entries(result.extractedData).map(([key, value]) => (
                <div key={key} className="flex">
                  <span className="text-sm font-medium text-gray-600 w-1/3">{key}:</span>
                  <span className="text-sm text-gray-900 w-2/3">
                    {typeof value === 'object' 
                      ? JSON.stringify(value) 
                      : String(value)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {result.analysis && (
          <div className="bg-blue-50 rounded-lg p-4">
            <h4 className="text-sm font-medium text-blue-700 mb-2">Analysis</h4>
            <p className="text-sm text-blue-900">{result.analysis}</p>
          </div>
        )}

        {result.anomalies && result.anomalies.length > 0 && (
          <div className="bg-yellow-50 rounded-lg p-4">
            <h4 className="text-sm font-medium text-yellow-700 mb-2">Anomalies Detected</h4>
            <ul className="list-disc pl-5">
              {result.anomalies.map((anomaly: string, index: number) => (
                <li key={index} className="text-sm text-yellow-900">{anomaly}</li>
              ))}
            </ul>
          </div>
        )}

        <button
          onClick={() => setShowRaw(!showRaw)}
          className="flex items-center space-x-2 text-sm text-gray-600 hover:text-gray-900"
        >
          {showRaw ? (
            <>
              <ChevronUp size={16} />
              <span>Hide Raw Data</span>
            </>
          ) : (
            <>
              <ChevronDown size={16} />
              <span>View Raw Data</span>
            </>
          )}
        </button>

        {showRaw && (
          <div className="bg-gray-100 rounded-lg p-4 overflow-auto max-h-64">
            <pre className="text-xs text-gray-800 whitespace-pre-wrap">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResultDisplay;