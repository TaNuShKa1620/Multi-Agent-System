import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, X, FileType, FilePlus2 } from 'lucide-react';

interface FileUploadProps {
  onSubmit: (file: File) => void;
  isProcessing: boolean;
}

const FileUpload: React.FC<FileUploadProps> = ({ onSubmit, isProcessing }) => {
  const [file, setFile] = useState<File | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles && acceptedFiles.length > 0) {
      setFile(acceptedFiles[0]);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/json': ['.json'],
      'text/plain': ['.txt'],
      'application/pdf': ['.pdf'],
    },
    maxFiles: 1,
    disabled: isProcessing,
  });

  const removeFile = () => {
    setFile(null);
  };

  const handleSubmit = () => {
    if (file) {
      onSubmit(file);
    }
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('json')) {
      return <FileType className="h-8 w-8 text-yellow-500" />;
    } else if (fileType.includes('pdf')) {
      return <FilePlus2 className="h-8 w-8 text-red-500" />;
    } else {
      return <FileType className="h-8 w-8 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-6 cursor-pointer transition-colors ${
          isDragActive
            ? 'border-blue-400 bg-blue-50'
            : 'border-gray-300 hover:border-gray-400 bg-white'
        } ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center justify-center space-y-2">
          <Upload
            className={`h-10 w-10 ${
              isDragActive ? 'text-blue-600' : 'text-gray-400'
            }`}
          />
          <p className="text-sm text-center text-gray-600">
            {isDragActive
              ? 'Drop the file here...'
              : 'Drag & drop a file here, or click to select a file'}
          </p>
          <p className="text-xs text-gray-500">
            Supported formats: JSON, TXT, PDF
          </p>
        </div>
      </div>

      {file && (
        <div className="bg-gray-50 rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {getFileIcon(file.type)}
            <div>
              <p className="text-sm font-medium text-gray-900 truncate max-w-xs">
                {file.name}
              </p>
              <p className="text-xs text-gray-500">
                {(file.size / 1024).toFixed(2)} KB
              </p>
            </div>
          </div>
          <button
            onClick={removeFile}
            disabled={isProcessing}
            className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100"
          >
            <X size={18} />
          </button>
        </div>
      )}

      <button
        onClick={handleSubmit}
        disabled={!file || isProcessing}
        className={`w-full py-2 px-4 rounded-md font-medium transition-colors ${
          !file || isProcessing
            ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
            : 'bg-blue-600 text-white hover:bg-blue-700'
        }`}
      >
        {isProcessing ? 'Processing...' : 'Process File'}
      </button>
    </div>
  );
};

export default FileUpload;