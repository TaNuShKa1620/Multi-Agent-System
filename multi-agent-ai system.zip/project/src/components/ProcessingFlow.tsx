import React from 'react';
import { Cpu, ArrowRight, FileCheck, Database } from 'lucide-react';

interface ProcessingFlowProps {
  currentStage: number;
}

const ProcessingFlow: React.FC<ProcessingFlowProps> = ({ currentStage }) => {
  const stages = [
    { 
      icon: <Cpu className="h-6 w-6" />, 
      title: 'Classifier Agent', 
      description: 'Identifying format and intent' 
    },
    { 
      icon: <ArrowRight className="h-6 w-6" />, 
      title: 'Specialized Agent', 
      description: 'Processing with dedicated agent' 
    },
    { 
      icon: <Database className="h-6 w-6" />, 
      title: 'Memory Storage', 
      description: 'Saving results and context' 
    },
    { 
      icon: <FileCheck className="h-6 w-6" />, 
      title: 'Complete', 
      description: 'Processing finished' 
    }
  ];

  return (
    <div className="py-4">
      <div className="flex items-center justify-between">
        {stages.map((stage, index) => (
          <React.Fragment key={index}>
            <div className="flex flex-col items-center">
              <div
                className={`flex items-center justify-center w-10 h-10 rounded-full ${
                  index <= currentStage
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-500'
                } transition-colors duration-300`}
              >
                {stage.icon}
              </div>
              <div className="text-center mt-2">
                <p className={`text-sm font-medium ${
                  index <= currentStage ? 'text-gray-900' : 'text-gray-500'
                }`}>
                  {stage.title}
                </p>
                <p className="text-xs text-gray-500 mt-1">{stage.description}</p>
              </div>
            </div>
            {index < stages.length - 1 && (
              <div 
                className={`flex-1 h-1 mx-2 ${
                  index < currentStage ? 'bg-blue-600' : 'bg-gray-200'
                } transition-colors duration-300`}
              />
            )}
          </React.Fragment>
        ))}
      </div>

      <div className="mt-8">
        <div className="animate-pulse h-8 bg-gray-200 rounded-md w-full mb-3"></div>
        <div className="animate-pulse h-4 bg-gray-200 rounded-md w-3/4 mb-2"></div>
        <div className="animate-pulse h-4 bg-gray-200 rounded-md w-1/2"></div>
      </div>
    </div>
  );
};

export default ProcessingFlow;