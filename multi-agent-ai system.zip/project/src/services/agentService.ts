import { v4 as uuidv4 } from 'uuid';

// Types
export interface Classification {
  format: 'JSON' | 'Email' | 'PDF';
  intent: string;
}

export interface ProcessedResult {
  id: string;
  timestamp: string;
  classification: Classification;
  extractedData: any;
  analysis?: string;
  anomalies?: string[];
}

// Classifier Agent
export const classifyInput = async (input: string | File): Promise<Classification> => {
  // Simulate API call with a delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  let format: Classification['format'] = 'Email';
  let intent = 'Unknown';
  
  // Basic classification logic
  if (input instanceof File) {
    if (input.name.endsWith('.json')) {
      format = 'JSON';
      intent = 'Data Import';
    } else if (input.name.endsWith('.pdf')) {
      format = 'PDF';
      intent = 'Document Review';
    } else {
      format = 'Email';
      intent = 'Correspondence';
    }
  } else {
    // String input
    if (input.trim().startsWith('{') && input.trim().endsWith('}')) {
      try {
        JSON.parse(input);
        format = 'JSON';
        intent = detectJsonIntent(input);
      } catch {
        format = 'Email';
        intent = detectEmailIntent(input);
      }
    } else {
      format = 'Email';
      intent = detectEmailIntent(input);
    }
  }
  
  return { format, intent };
};

// Intent detection helpers
const detectJsonIntent = (jsonStr: string): string => {
  const json = JSON.parse(jsonStr);
  
  if (json.invoice || json.invoiceNumber || json.billing) {
    return 'Invoice';
  } else if (json.request || json.quote || json.rfq) {
    return 'RFQ';
  } else if (json.complaint || json.issue) {
    return 'Complaint';
  } else if (json.regulation || json.compliance) {
    return 'Regulation';
  }
  
  return 'Data Import';
};

const detectEmailIntent = (text: string): string => {
  const lowerText = text.toLowerCase();
  
  if (lowerText.includes('invoice') || lowerText.includes('payment') || lowerText.includes('bill')) {
    return 'Invoice';
  } else if (lowerText.includes('quote') || lowerText.includes('proposal') || lowerText.includes('estimate')) {
    return 'RFQ';
  } else if (lowerText.includes('complaint') || lowerText.includes('issue') || lowerText.includes('problem')) {
    return 'Complaint';
  } else if (lowerText.includes('urgent') || lowerText.includes('immediately')) {
    return 'Urgent';
  }
  
  return 'Correspondence';
};

// Main processing function
export const processInput = async (input: string | File, classification: Classification): Promise<ProcessedResult> => {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  let result: ProcessedResult = {
    id: uuidv4(),
    timestamp: new Date().toISOString(),
    classification,
    extractedData: {}
  };
  
  // Process based on format
  if (classification.format === 'JSON') {
    return await processJson(input as string, result);
  } else if (classification.format === 'Email') {
    return await processEmail(input as string, result);
  } else {
    // Basic placeholder for PDF processing
    result.extractedData = {
      message: "PDF processing is not fully implemented yet."
    };
    return result;
  }
};

// JSON Agent
const processJson = async (input: string, result: ProcessedResult): Promise<ProcessedResult> => {
  try {
    const jsonData = JSON.parse(typeof input === 'string' ? input : '{}');
    
    // Extract common fields
    result.extractedData = {
      ...jsonData,
      processedAt: new Date().toISOString()
    };
    
    // Check for anomalies
    const anomalies = [];
    
    // Check for missing required fields based on intent
    if (result.classification.intent === 'Invoice') {
      if (!jsonData.invoiceNumber) anomalies.push('Missing invoice number');
      if (!jsonData.amount) anomalies.push('Missing invoice amount');
    } else if (result.classification.intent === 'RFQ') {
      if (!jsonData.requestId) anomalies.push('Missing request ID');
      if (!jsonData.items || !Array.isArray(jsonData.items)) anomalies.push('Missing or invalid items list');
    }
    
    // Add analysis
    if (anomalies.length > 0) {
      result.anomalies = anomalies;
      result.analysis = `Processed JSON with ${anomalies.length} anomalies.`;
    } else {
      result.analysis = 'JSON data processed successfully with no anomalies detected.';
    }
    
    return result;
  } catch (error) {
    result.anomalies = ['Invalid JSON format'];
    result.analysis = 'Failed to parse JSON data.';
    return result;
  }
};

// Email Agent
const processEmail = async (input: string, result: ProcessedResult): Promise<ProcessedResult> => {
  const lines = input.split('\n').filter(line => line.trim() !== '');
  
  // Basic extraction of email components
  const extractedData: any = {
    processed: true
  };
  
  // Try to find sender
  const fromMatch = input.match(/from:?\s*([^\n]+)/i) || input.match(/([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/i);
  if (fromMatch) {
    extractedData.sender = fromMatch[1].trim();
  }
  
  // Try to find subject
  const subjectMatch = input.match(/subject:?\s*([^\n]+)/i);
  if (subjectMatch) {
    extractedData.subject = subjectMatch[1].trim();
  } else if (lines.length > 0) {
    // Use first line as subject if no explicit subject
    extractedData.subject = lines[0].trim();
  }
  
  // Extract body (everything except headers)
  extractedData.body = lines.slice(lines.length > 2 ? 2 : 1).join('\n').trim();
  
  // Determine urgency
  const urgentTerms = ['urgent', 'asap', 'immediately', 'emergency'];
  extractedData.urgency = urgentTerms.some(term => input.toLowerCase().includes(term)) ? 'High' : 'Normal';
  
  // Add to result
  result.extractedData = extractedData;
  result.analysis = `Email processed with ${extractedData.urgency} urgency.`;
  
  return result;
};