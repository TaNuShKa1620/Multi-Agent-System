import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define memory entry types
export interface Classification {
  format: string;
  intent: string;
}

export interface MemoryEntry {
  id: string;
  timestamp: string;
  classification: Classification;
  result: any;
}

interface MemoryContextType {
  memory: MemoryEntry[];
  addToMemory: (entry: MemoryEntry) => void;
  clearMemory: () => void;
  getEntryById: (id: string) => MemoryEntry | undefined;
}

const MemoryContext = createContext<MemoryContextType | undefined>(undefined);

export const useMemory = () => {
  const context = useContext(MemoryContext);
  if (context === undefined) {
    throw new Error('useMemory must be used within a MemoryProvider');
  }
  return context;
};

interface MemoryProviderProps {
  children: ReactNode;
}

export const MemoryProvider: React.FC<MemoryProviderProps> = ({ children }) => {
  const [memory, setMemory] = useState<MemoryEntry[]>(() => {
    // Load from localStorage on initial render
    const savedMemory = localStorage.getItem('aiAgentMemory');
    return savedMemory ? JSON.parse(savedMemory) : [];
  });

  useEffect(() => {
    // Save to localStorage whenever memory changes
    localStorage.setItem('aiAgentMemory', JSON.stringify(memory));
  }, [memory]);

  const addToMemory = (entry: MemoryEntry) => {
    setMemory(prevMemory => [entry, ...prevMemory]);
  };

  const clearMemory = () => {
    setMemory([]);
  };

  const getEntryById = (id: string) => {
    return memory.find(entry => entry.id === id);
  };

  return (
    <MemoryContext.Provider value={{ memory, addToMemory, clearMemory, getEntryById }}>
      {children}
    </MemoryContext.Provider>
  );
};